// ─── Database Row Types ────────────────────────────────────────────────────────

export interface UserProfile {
  id: string;           // matches auth.users.id
  username: string;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  follower_count: number;
  following_count: number;
  created_at: string;
}

export interface Video {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  video_path: string;       // path inside "videos" storage bucket
  thumbnail_path: string | null;
  like_count: number;
  comment_count: number;
  share_count: number;
  view_count: number;
  created_at: string;
  // joined
  profiles?: UserProfile;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  created_at: string;
  // joined
  profiles?: UserProfile;
}

export interface Conversation {
  id: string;
  created_at: string;
  // joined
  participants?: UserProfile[];
  last_message?: Message | null;
}

// ─── Supabase Database generic (used by createClient) ─────────────────────────

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: UserProfile;
        Insert: Partial<UserProfile> & { id: string; username: string };
        Update: Partial<UserProfile>;
      };
      videos: {
        Row: Video;
        Insert: Omit<Video, "id" | "created_at" | "like_count" | "comment_count" | "share_count" | "view_count">;
        Update: Partial<Video>;
      };
      messages: {
        Row: Message;
        Insert: Omit<Message, "id" | "created_at">;
        Update: Partial<Message>;
      };
      conversations: {
        Row: Conversation;
        Insert: Omit<Conversation, "id" | "created_at">;
        Update: Partial<Conversation>;
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
  };
};

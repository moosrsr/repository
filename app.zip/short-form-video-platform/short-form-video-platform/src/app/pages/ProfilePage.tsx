import { useEffect, useState } from "react";
import { supabase, getStorageUrl } from "@/lib/supabase";
import { useAuth } from "@/app/contexts/AuthContext";
import type { Video } from "@/lib/types";
import { Avatar, AvatarFallback, AvatarImage } from "@/app/components/ui/avatar";
import { Button } from "@/app/components/ui/button";
import { LogOut, Settings, Grid3X3 } from "lucide-react";

export default function ProfilePage() {
  const { profile, signOut, user } = useAuth();
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("videos")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setVideos(data ?? []);
        setLoading(false);
      });
  }, [user]);

  if (!profile) return null;

  return (
    <div className="flex h-full flex-col overflow-y-auto bg-background pb-20">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-4">
        <h1 className="text-lg font-semibold">Profile</h1>
        <div className="flex gap-2">
          <Button variant="ghost" size="icon">
            <Settings className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" onClick={signOut}>
            <LogOut className="h-5 w-5 text-destructive" />
          </Button>
        </div>
      </div>

      {/* Profile Card */}
      <div className="flex flex-col items-center gap-3 px-6 pb-6">
        <Avatar className="h-20 w-20 ring-4 ring-primary ring-offset-2 ring-offset-background">
          <AvatarImage src={profile.avatar_url ?? undefined} />
          <AvatarFallback className="bg-primary text-2xl text-primary-foreground">
            {profile.username[0].toUpperCase()}
          </AvatarFallback>
        </Avatar>

        <div className="text-center">
          <h2 className="text-xl font-bold">{profile.display_name ?? profile.username}</h2>
          <p className="text-sm text-muted-foreground">@{profile.username}</p>
          {profile.bio && (
            <p className="mt-2 max-w-xs text-sm text-foreground/80">{profile.bio}</p>
          )}
        </div>

        {/* Stats */}
        <div className="flex gap-8 py-2">
          <StatItem value={videos.length} label="Videos" />
          <StatItem value={profile.follower_count} label="Followers" />
          <StatItem value={profile.following_count} label="Following" />
        </div>

        <Button variant="outline" className="w-full max-w-xs">
          Edit Profile
        </Button>
      </div>

      {/* Video Grid */}
      <div className="border-t border-border px-1 pt-1">
        <div className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-muted-foreground">
          <Grid3X3 className="h-4 w-4" />
          Videos
        </div>

        {loading ? (
          <div className="flex h-40 items-center justify-center">
            <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        ) : videos.length === 0 ? (
          <div className="flex h-40 flex-col items-center justify-center gap-2 text-muted-foreground">
            <p className="text-sm">No videos yet</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-0.5">
            {videos.map((v) => {
              const thumb = v.thumbnail_path
                ? getStorageUrl("thumbnails", v.thumbnail_path)
                : undefined;
              return (
                <div key={v.id} className="relative aspect-[9/16] overflow-hidden bg-secondary">
                  {thumb ? (
                    <img
                      src={thumb}
                      alt={v.title}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-muted">
                      <span className="text-xs text-muted-foreground">No preview</span>
                    </div>
                  )}
                  <div className="absolute bottom-1 left-1 rounded bg-black/60 px-1 py-0.5 text-[10px] text-white">
                    {formatCount(v.view_count)} views
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function StatItem({ value, label }: { value: number; label: string }) {
  return (
    <div className="flex flex-col items-center">
      <span className="text-xl font-bold">{formatCount(value)}</span>
      <span className="text-xs text-muted-foreground">{label}</span>
    </div>
  );
}

function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

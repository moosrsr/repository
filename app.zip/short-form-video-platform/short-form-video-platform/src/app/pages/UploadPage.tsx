import { useRef, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/app/contexts/AuthContext";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Upload, Video, CheckCircle2 } from "lucide-react";
import { useNavigate } from "react-router";

type UploadStatus = "idle" | "uploading" | "success" | "error";

export default function UploadPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileRef = useRef<HTMLInputElement>(null);
  const thumbRef = useRef<HTMLInputElement>(null);

  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [thumbFile, setThumbFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState<UploadStatus>("idle");
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const handleUpload = async () => {
    if (!user || !videoFile || !title.trim()) return;
    setStatus("uploading");
    setError(null);
    setProgress(10);

    try {
      // Upload video file
      const videoExt = videoFile.name.split(".").pop();
      const videoPath = `${user.id}/${Date.now()}.${videoExt}`;

      const { error: vidErr } = await supabase.storage
        .from("videos")
        .upload(videoPath, videoFile, { upsert: false });

      if (vidErr) throw new Error(vidErr.message);
      setProgress(60);

      // Upload thumbnail if provided
      let thumbnailPath: string | null = null;
      if (thumbFile) {
        const thumbExt = thumbFile.name.split(".").pop();
        thumbnailPath = `${user.id}/${Date.now()}_thumb.${thumbExt}`;
        const { error: thumbErr } = await supabase.storage
          .from("thumbnails")
          .upload(thumbnailPath, thumbFile, { upsert: false });
        if (thumbErr) thumbnailPath = null; // non-fatal
      }

      setProgress(80);

      // Insert video record
      const { error: dbErr } = await supabase.from("videos").insert({
        user_id: user.id,
        title: title.trim(),
        description: description.trim() || null,
        video_path: videoPath,
        thumbnail_path: thumbnailPath,
      });

      if (dbErr) throw new Error(dbErr.message);

      setProgress(100);
      setStatus("success");

      setTimeout(() => navigate("/"), 1500);
    } catch (e: unknown) {
      setError((e as Error).message);
      setStatus("error");
    }
  };

  return (
    <div className="flex h-full flex-col overflow-y-auto bg-background px-4 pb-24">
      <div className="py-4">
        <h1 className="text-xl font-bold">Upload Video</h1>
        <p className="text-sm text-muted-foreground">Share your moment with the world</p>
      </div>

      {/* Video picker */}
      <div
        onClick={() => fileRef.current?.click()}
        className="mb-4 flex cursor-pointer flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed border-border bg-card py-10 transition-colors hover:border-primary hover:bg-primary/5"
      >
        {videoFile ? (
          <>
            <Video className="h-10 w-10 text-primary" />
            <p className="text-sm font-medium text-foreground">{videoFile.name}</p>
            <p className="text-xs text-muted-foreground">
              {(videoFile.size / 1_000_000).toFixed(1)} MB
            </p>
          </>
        ) : (
          <>
            <Upload className="h-10 w-10 text-muted-foreground" />
            <p className="text-sm font-medium">Tap to select a video</p>
            <p className="text-xs text-muted-foreground">MP4, MOV, WebM up to 100MB</p>
          </>
        )}
        <input
          ref={fileRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={(e) => setVideoFile(e.target.files?.[0] ?? null)}
        />
      </div>

      {/* Thumbnail */}
      <div className="mb-4 space-y-2">
        <label className="text-sm font-medium">Thumbnail (optional)</label>
        <div
          onClick={() => thumbRef.current?.click()}
          className="flex cursor-pointer items-center gap-3 rounded-lg border border-border bg-card px-4 py-3 text-sm text-muted-foreground transition-colors hover:border-primary"
        >
          {thumbFile ? thumbFile.name : "Choose image…"}
          <input
            ref={thumbRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => setThumbFile(e.target.files?.[0] ?? null)}
          />
        </div>
      </div>

      {/* Title */}
      <div className="mb-4 space-y-2">
        <label className="text-sm font-medium">
          Title <span className="text-destructive">*</span>
        </label>
        <Input
          placeholder="Give your video a catchy title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          maxLength={100}
          className="bg-card"
        />
      </div>

      {/* Description */}
      <div className="mb-6 space-y-2">
        <label className="text-sm font-medium">Caption</label>
        <textarea
          placeholder="Describe your video…"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          maxLength={300}
          rows={3}
          className="w-full resize-none rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        />
        <p className="text-right text-xs text-muted-foreground">{description.length}/300</p>
      </div>

      {/* Progress */}
      {status === "uploading" && (
        <div className="mb-4 space-y-1">
          <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
            <div
              className="h-full rounded-full bg-primary transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground">Uploading… {progress}%</p>
        </div>
      )}

      {error && (
        <p className="mb-4 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {error}
        </p>
      )}

      {status === "success" ? (
        <div className="flex items-center justify-center gap-2 rounded-xl bg-primary/10 py-4 text-primary">
          <CheckCircle2 className="h-5 w-5" />
          <span className="font-medium">Uploaded! Redirecting…</span>
        </div>
      ) : (
        <Button
          className="w-full"
          size="lg"
          disabled={!videoFile || !title.trim() || status === "uploading"}
          onClick={handleUpload}
        >
          {status === "uploading" ? "Uploading…" : "Post Video"}
        </Button>
      )}
    </div>
  );
}

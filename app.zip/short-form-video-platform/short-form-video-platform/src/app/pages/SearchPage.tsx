import { useState } from "react";
import { supabase, getStorageUrl } from "@/lib/supabase";
import type { Video } from "@/lib/types";
import { Input } from "@/app/components/ui/input";
import { Search } from "lucide-react";

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Video[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const doSearch = async (q: string) => {
    if (!q.trim()) {
      setResults([]);
      setSearched(false);
      return;
    }
    setLoading(true);
    const { data } = await supabase
      .from("videos")
      .select("*, profiles(*)")
      .or(`title.ilike.%${q}%,description.ilike.%${q}%`)
      .order("view_count", { ascending: false })
      .limit(20);

    setResults(data ?? []);
    setLoading(false);
    setSearched(true);
  };

  return (
    <div className="flex h-full flex-col bg-background">
      {/* Search Bar */}
      <div className="px-4 py-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="pl-9 bg-card"
            placeholder="Search videos, creators…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && doSearch(query)}
          />
        </div>
      </div>

      {/* Results */}
      <div className="flex-1 overflow-y-auto pb-20">
        {loading && (
          <div className="flex h-32 items-center justify-center">
            <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        )}

        {searched && !loading && results.length === 0 && (
          <div className="flex h-32 flex-col items-center justify-center gap-2 text-muted-foreground">
            <p>No results for "{query}"</p>
          </div>
        )}

        {results.length > 0 && (
          <div className="grid grid-cols-2 gap-0.5 px-0.5">
            {results.map((v) => {
              const thumb = v.thumbnail_path
                ? getStorageUrl("thumbnails", v.thumbnail_path)
                : undefined;
              return (
                <div key={v.id} className="relative aspect-[9/16] overflow-hidden bg-secondary">
                  {thumb ? (
                    <img src={thumb} alt={v.title} className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-muted text-xs text-muted-foreground">
                      No preview
                    </div>
                  )}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-2">
                    <p className="truncate text-xs font-medium text-white">{v.title}</p>
                    <p className="text-[10px] text-white/70">
                      @{v.profiles?.username}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {!searched && !loading && (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-muted-foreground">
            <Search className="h-12 w-12 opacity-20" />
            <p className="text-sm">Search for videos or creators</p>
          </div>
        )}
      </div>
    </div>
  );
}

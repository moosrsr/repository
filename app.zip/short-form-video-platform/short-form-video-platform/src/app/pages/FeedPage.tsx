import { useEffect, useRef, useState, useCallback } from "react";
import { supabase, getStorageUrl } from "@/lib/supabase";
import type { Video } from "@/lib/types";
import { Heart, MessageCircle, Share2, Bookmark, Volume2, VolumeX, ChevronUp } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/app/components/ui/avatar";
import { cn } from "@/app/components/ui/utils";
import { useAuth } from "@/app/contexts/AuthContext";

const PAGE_SIZE = 5;

export default function FeedPage() {
  const { user } = useAuth();
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);

  const fetchVideos = useCallback(async (pageNum: number) => {
    const { data, error } = await supabase
      .from("videos")
      .select("*, profiles(*)")
      .order("created_at", { ascending: false })
      .range(pageNum * PAGE_SIZE, pageNum * PAGE_SIZE + PAGE_SIZE - 1);

    if (error) {
      console.error("Error fetching videos:", error.message);
      return;
    }

    if ((data ?? []).length < PAGE_SIZE) setHasMore(false);
    setVideos((prev) => (pageNum === 0 ? (data ?? []) : [...prev, ...(data ?? [])]));
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchVideos(0);
  }, [fetchVideos]);

  // Intersection observer to load more as user scrolls down
  const sentinelRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!sentinelRef.current || !hasMore) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setPage((p) => {
            const next = p + 1;
            fetchVideos(next);
            return next;
          });
        }
      },
      { threshold: 0.5 }
    );
    obs.observe(sentinelRef.current);
    return () => obs.disconnect();
  }, [fetchVideos, hasMore, videos.length]);

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  if (videos.length === 0) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-4 text-muted-foreground">
        <ChevronUp className="h-12 w-12 animate-bounce" />
        <p className="text-lg font-medium">No videos yet</p>
        <p className="text-sm">Be the first to upload!</p>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="video-snap scrollbar-hide h-full overflow-y-scroll"
    >
      {videos.map((video) => (
        <VideoItem key={video.id} video={video} userId={user?.id} />
      ))}

      {hasMore && (
        <div ref={sentinelRef} className="flex h-screen items-center justify-center">
          <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        </div>
      )}
    </div>
  );
}

// ─── Single Video Item ──────────────────────────────────────────────────────

function VideoItem({ video, userId }: { video: Video; userId?: string }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [muted, setMuted] = useState(true);
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(video.like_count);

  const videoUrl = getStorageUrl("videos", video.video_path);
  const thumbnailUrl = video.thumbnail_path
    ? getStorageUrl("thumbnails", video.thumbnail_path)
    : undefined;

  // Auto-play when visible
  useEffect(() => {
    const el = wrapperRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          videoRef.current?.play().catch(() => {});
          // Increment view count (fire-and-forget)
          supabase
            .from("videos")
            .update({ view_count: video.view_count + 1 })
            .eq("id", video.id);
        } else {
          videoRef.current?.pause();
        }
      },
      { threshold: 0.8 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [video.id, video.view_count]);

  const toggleLike = async () => {
    if (!userId) return;
    const next = !liked;
    setLiked(next);
    const delta = next ? 1 : -1;
    setLikeCount((c) => c + delta);
    await supabase
      .from("videos")
      .update({ like_count: likeCount + delta })
      .eq("id", video.id);
  };

  const profile = video.profiles;

  return (
    <div
      ref={wrapperRef}
      className="relative flex h-screen w-full items-end overflow-hidden bg-black"
    >
      {/* Video */}
      <video
        ref={videoRef}
        src={videoUrl}
        poster={thumbnailUrl}
        muted={muted}
        loop
        playsInline
        className="absolute inset-0 h-full w-full object-cover"
        onClick={() => setMuted((m) => !m)}
      />

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

      {/* Info panel */}
      <div className="relative z-10 flex w-full items-end justify-between gap-4 p-4 pb-20">
        {/* Left: creator + caption */}
        <div className="flex-1 space-y-2">
          <div className="flex items-center gap-2">
            <Avatar className="h-9 w-9 ring-2 ring-primary">
              <AvatarImage src={profile?.avatar_url ?? undefined} />
              <AvatarFallback className="bg-primary text-xs text-primary-foreground">
                {profile?.username?.[0]?.toUpperCase() ?? "?"}
              </AvatarFallback>
            </Avatar>
            <span className="font-semibold text-white">
              @{profile?.username ?? "unknown"}
            </span>
          </div>
          <p className="text-sm leading-snug text-white/90">{video.description}</p>
          <p className="text-xs font-medium text-white/60">{video.title}</p>
        </div>

        {/* Right: action buttons */}
        <div className="flex flex-col items-center gap-5 pb-2">
          <ActionBtn
            icon={<Heart className={cn("h-7 w-7", liked && "fill-red-500 text-red-500")} />}
            label={formatCount(likeCount)}
            onClick={toggleLike}
          />
          <ActionBtn
            icon={<MessageCircle className="h-7 w-7" />}
            label={formatCount(video.comment_count)}
          />
          <ActionBtn
            icon={<Share2 className="h-7 w-7" />}
            label={formatCount(video.share_count)}
          />
          <ActionBtn icon={<Bookmark className="h-7 w-7" />} label="Save" />
          <button
            onClick={() => setMuted((m) => !m)}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20 backdrop-blur"
          >
            {muted ? (
              <VolumeX className="h-5 w-5 text-white" />
            ) : (
              <Volume2 className="h-5 w-5 text-white" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

function ActionBtn({
  icon,
  label,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1 text-white transition-transform active:scale-90"
    >
      {icon}
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
}

function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

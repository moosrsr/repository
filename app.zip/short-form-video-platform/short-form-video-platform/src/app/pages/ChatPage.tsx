import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { Conversation, Message, UserProfile } from "@/lib/types";
import { useAuth } from "@/app/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/app/components/ui/avatar";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { ArrowLeft, Send, MessageCircle } from "lucide-react";
import { cn } from "@/app/components/ui/utils";
import type { RealtimeChannel } from "@supabase/supabase-js";

// ─── Main Chat Page ────────────────────────────────────────────────────────────

export default function ChatPage() {
  const { user, profile } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [loadingConvos, setLoadingConvos] = useState(true);

  const fetchConversations = useCallback(async () => {
    if (!user) return;

    // Get conversations where the current user is a participant
    const { data: participantRows } = await supabase
      .from("conversation_participants")
      .select("conversation_id")
      .eq("user_id", user.id);

    const convoIds = (participantRows ?? []).map((r) => r.conversation_id);
    if (convoIds.length === 0) {
      setLoadingConvos(false);
      return;
    }

    const { data: convos } = await supabase
      .from("conversations")
      .select("*")
      .in("id", convoIds)
      .order("created_at", { ascending: false });

    if (!convos) return;

    // Enrich each conversation with other participants + last message
    const enriched = await Promise.all(
      convos.map(async (c) => {
        const { data: partRows } = await supabase
          .from("conversation_participants")
          .select("user_id")
          .eq("conversation_id", c.id);

        const otherIds = (partRows ?? [])
          .map((r) => r.user_id)
          .filter((id) => id !== user.id);

        const { data: profiles } = await supabase
          .from("profiles")
          .select("*")
          .in("id", otherIds);

        const { data: lastMsgs } = await supabase
          .from("messages")
          .select("*")
          .eq("conversation_id", c.id)
          .order("created_at", { ascending: false })
          .limit(1);

        return {
          ...c,
          participants: profiles ?? [],
          last_message: lastMsgs?.[0] ?? null,
        } as Conversation;
      })
    );

    setConversations(enriched);
    setLoadingConvos(false);
  }, [user]);

  useEffect(() => {
    fetchConversations();
  }, [fetchConversations]);

  if (!user || !profile) return null;

  // Show conversation list
  if (!activeConversation) {
    return (
      <div className="flex h-full flex-col bg-background">
        <div className="flex items-center gap-2 border-b border-border px-4 py-3">
          <MessageCircle className="h-5 w-5 text-primary" />
          <h1 className="text-lg font-semibold">Messages</h1>
        </div>

        {loadingConvos ? (
          <div className="flex flex-1 items-center justify-center">
            <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        ) : conversations.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 text-muted-foreground">
            <MessageCircle className="h-12 w-12 opacity-30" />
            <p>No conversations yet</p>
            <p className="text-xs">Start chatting from someone's profile</p>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto">
            {conversations.map((convo) => {
              const other = convo.participants?.[0];
              return (
                <button
                  key={convo.id}
                  onClick={() => setActiveConversation(convo)}
                  className="flex w-full items-center gap-3 px-4 py-3 transition-colors hover:bg-secondary"
                >
                  <Avatar>
                    <AvatarImage src={other?.avatar_url ?? undefined} />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {other?.username?.[0]?.toUpperCase() ?? "?"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1 text-left">
                    <p className="font-medium">
                      {other?.display_name ?? other?.username ?? "Unknown"}
                    </p>
                    <p className="truncate text-sm text-muted-foreground">
                      {convo.last_message?.content ?? "No messages yet"}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  return (
    <ConversationView
      conversation={activeConversation}
      currentUserId={user.id}
      onBack={() => {
        setActiveConversation(null);
        fetchConversations();
      }}
    />
  );
}

// ─── Conversation View ─────────────────────────────────────────────────────────

function ConversationView({
  conversation,
  currentUserId,
  onBack,
}: {
  conversation: Conversation;
  currentUserId: string;
  onBack: () => void;
}) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const channelRef = useRef<RealtimeChannel | null>(null);

  const other = conversation.participants?.[0] as UserProfile | undefined;

  // Initial message load
  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from("messages")
        .select("*, profiles(*)")
        .eq("conversation_id", conversation.id)
        .order("created_at", { ascending: true });
      setMessages(data ?? []);
    };
    load();
  }, [conversation.id]);

  // Subscribe to new messages via Supabase Realtime
  useEffect(() => {
    channelRef.current = supabase
      .channel(`conversation:${conversation.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `conversation_id=eq.${conversation.id}`,
        },
        async (payload) => {
          // Fetch full message with profile
          const { data } = await supabase
            .from("messages")
            .select("*, profiles(*)")
            .eq("id", payload.new.id)
            .single();
          if (data) setMessages((prev) => [...prev, data]);
        }
      )
      .subscribe();

    return () => {
      channelRef.current?.unsubscribe();
    };
  }, [conversation.id]);

  // Scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async () => {
    const content = text.trim();
    if (!content || sending) return;

    setSending(true);
    setText("");

    const { error } = await supabase.from("messages").insert({
      conversation_id: conversation.id,
      sender_id: currentUserId,
      content,
    });

    if (error) {
      console.error("Send failed:", error.message);
      setText(content); // restore
    }

    setSending(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex h-full flex-col bg-background">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-border px-3 py-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="shrink-0"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <Avatar className="h-9 w-9">
          <AvatarImage src={other?.avatar_url ?? undefined} />
          <AvatarFallback className="bg-primary text-primary-foreground text-sm">
            {other?.username?.[0]?.toUpperCase() ?? "?"}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0">
          <p className="font-semibold truncate">
            {other?.display_name ?? other?.username ?? "Unknown"}
          </p>
          <p className="text-xs text-muted-foreground">@{other?.username}</p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {messages.map((msg) => {
          const isMe = msg.sender_id === currentUserId;
          return (
            <div
              key={msg.id}
              className={cn(
                "flex max-w-[75%] flex-col gap-1",
                isMe ? "ml-auto items-end" : "items-start"
              )}
            >
              <div
                className={cn(
                  "rounded-2xl px-4 py-2 text-sm leading-relaxed",
                  isMe
                    ? "rounded-br-sm bg-primary text-primary-foreground"
                    : "rounded-bl-sm bg-secondary text-secondary-foreground"
                )}
              >
                {msg.content}
              </div>
              <span className="px-1 text-[10px] text-muted-foreground">
                {new Date(msg.created_at).toLocaleTimeString([], {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </span>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="border-t border-border px-3 py-3 pb-20">
        <div className="flex items-center gap-2">
          <Input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a message…"
            className="flex-1 bg-card"
            maxLength={1000}
          />
          <Button
            onClick={sendMessage}
            size="icon"
            disabled={!text.trim() || sending}
            className="shrink-0"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

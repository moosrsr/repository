import { NavLink } from "react-router";
import { Home, MessageCircle, PlusSquare, Search, User } from "lucide-react";
import { cn } from "@/app/components/ui/utils";

const navItems = [
  { to: "/", icon: Home, label: "Home" },
  { to: "/search", icon: Search, label: "Search" },
  { to: "/upload", icon: PlusSquare, label: "Upload" },
  { to: "/chat", icon: MessageCircle, label: "Chat" },
  { to: "/profile", icon: User, label: "Profile" },
];

export default function BottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 flex h-16 items-center justify-around border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      {navItems.map(({ to, icon: Icon, label }) => (
        <NavLink
          key={to}
          to={to}
          end={to === "/"}
          className={({ isActive }) =>
            cn(
              "flex flex-col items-center gap-1 px-3 py-1 text-xs transition-colors",
              isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
            )
          }
        >
          {({ isActive }) => (
            <>
              <Icon
                className={cn("h-6 w-6 transition-transform", isActive && "scale-110")}
                strokeWidth={isActive ? 2.5 : 1.8}
              />
              <span className="sr-only">{label}</span>
            </>
          )}
        </NavLink>
      ))}
    </nav>
  );
}

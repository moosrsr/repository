-- ============================================================
--  SHORT-FORM VIDEO PLATFORM — Supabase SQL Schema
--  Run this entire file once in:
--  Supabase Dashboard → SQL Editor → New Query → Run
-- ============================================================


-- ─────────────────────────────────────────────────────────────
-- 1. EXTENSIONS
-- ─────────────────────────────────────────────────────────────

create extension if not exists "uuid-ossp";


-- ─────────────────────────────────────────────────────────────
-- 2. TABLES
-- ─────────────────────────────────────────────────────────────

-- Profiles (one row per auth user)
create table if not exists public.profiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  username        text not null unique,
  display_name    text,
  avatar_url      text,
  bio             text,
  follower_count  integer not null default 0,
  following_count integer not null default 0,
  created_at      timestamptz not null default now()
);

-- Follows
create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (follower_id, following_id)
);

-- Videos
create table if not exists public.videos (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references public.profiles(id) on delete cascade,
  title           text not null,
  description     text,
  video_path      text not null,   -- path inside "videos" storage bucket
  thumbnail_path  text,            -- path inside "thumbnails" storage bucket
  like_count      integer not null default 0,
  comment_count   integer not null default 0,
  share_count     integer not null default 0,
  view_count      integer not null default 0,
  created_at      timestamptz not null default now()
);

-- Video likes (separate table for integrity)
create table if not exists public.video_likes (
  user_id    uuid not null references public.profiles(id) on delete cascade,
  video_id   uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, video_id)
);

-- Conversations (DM threads)
create table if not exists public.conversations (
  id         uuid primary key default uuid_generate_v4(),
  created_at timestamptz not null default now()
);

-- Who is in each conversation
create table if not exists public.conversation_participants (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id         uuid not null references public.profiles(id) on delete cascade,
  primary key (conversation_id, user_id)
);

-- Messages
create table if not exists public.messages (
  id              uuid primary key default uuid_generate_v4(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id       uuid not null references public.profiles(id) on delete cascade,
  content         text not null,
  created_at      timestamptz not null default now()
);


-- ─────────────────────────────────────────────────────────────
-- 3. INDEXES
-- ─────────────────────────────────────────────────────────────

create index if not exists idx_videos_user_id     on public.videos(user_id);
create index if not exists idx_videos_created_at  on public.videos(created_at desc);
create index if not exists idx_messages_convo_id  on public.messages(conversation_id);
create index if not exists idx_messages_created   on public.messages(created_at asc);
create index if not exists idx_participants_user  on public.conversation_participants(user_id);


-- ─────────────────────────────────────────────────────────────
-- 4. ROW LEVEL SECURITY (RLS)
-- ─────────────────────────────────────────────────────────────

alter table public.profiles                 enable row level security;
alter table public.follows                  enable row level security;
alter table public.videos                   enable row level security;
alter table public.video_likes              enable row level security;
alter table public.conversations            enable row level security;
alter table public.conversation_participants enable row level security;
alter table public.messages                 enable row level security;

-- ── profiles ──
create policy "Public profiles are viewable by everyone"
  on public.profiles for select using (true);

create policy "Users can insert their own profile"
  on public.profiles for insert with check (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles for update using (auth.uid() = id);

-- ── videos ──
create policy "Anyone can view videos"
  on public.videos for select using (true);

create policy "Authenticated users can insert videos"
  on public.videos for insert with check (auth.uid() = user_id);

create policy "Owners can update their videos"
  on public.videos for update using (auth.uid() = user_id);

create policy "Owners can delete their videos"
  on public.videos for delete using (auth.uid() = user_id);

-- ── video_likes ──
create policy "Anyone can view likes"
  on public.video_likes for select using (true);

create policy "Users can like videos"
  on public.video_likes for insert with check (auth.uid() = user_id);

create policy "Users can unlike their likes"
  on public.video_likes for delete using (auth.uid() = user_id);

-- ── follows ──
create policy "Anyone can view follows"
  on public.follows for select using (true);

create policy "Users can follow"
  on public.follows for insert with check (auth.uid() = follower_id);

create policy "Users can unfollow"
  on public.follows for delete using (auth.uid() = follower_id);

-- ── conversations ──
create policy "Participants can view conversations"
  on public.conversations for select using (
    exists (
      select 1 from public.conversation_participants cp
      where cp.conversation_id = id and cp.user_id = auth.uid()
    )
  );

create policy "Authenticated users can create conversations"
  on public.conversations for insert with check (auth.uid() is not null);

-- ── conversation_participants ──
create policy "Participants can view participant list"
  on public.conversation_participants for select using (
    exists (
      select 1 from public.conversation_participants cp
      where cp.conversation_id = conversation_id and cp.user_id = auth.uid()
    )
  );

create policy "Users can join conversations"
  on public.conversation_participants for insert with check (auth.uid() is not null);

-- ── messages ──
create policy "Participants can read messages"
  on public.messages for select using (
    exists (
      select 1 from public.conversation_participants cp
      where cp.conversation_id = conversation_id and cp.user_id = auth.uid()
    )
  );

create policy "Participants can send messages"
  on public.messages for insert with check (
    auth.uid() = sender_id
    and exists (
      select 1 from public.conversation_participants cp
      where cp.conversation_id = conversation_id and cp.user_id = auth.uid()
    )
  );


-- ─────────────────────────────────────────────────────────────
-- 5. REALTIME
--    Enable realtime for the messages table so the Chat UI
--    receives live updates without polling.
-- ─────────────────────────────────────────────────────────────

alter publication supabase_realtime add table public.messages;


-- ─────────────────────────────────────────────────────────────
-- 6. STORAGE BUCKETS
--    Create these via SQL so you don't have to click through
--    the dashboard.
-- ─────────────────────────────────────────────────────────────

-- videos bucket (public read)
insert into storage.buckets (id, name, public)
values ('videos', 'videos', true)
on conflict (id) do nothing;

-- thumbnails bucket (public read)
insert into storage.buckets (id, name, public)
values ('thumbnails', 'thumbnails', true)
on conflict (id) do nothing;

-- avatars bucket (public read)
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

-- Storage policies
create policy "Public video access"
  on storage.objects for select
  using (bucket_id = 'videos');

create policy "Authenticated users can upload videos"
  on storage.objects for insert
  with check (bucket_id = 'videos' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "Owners can delete their videos"
  on storage.objects for delete
  using (bucket_id = 'videos' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "Public thumbnail access"
  on storage.objects for select
  using (bucket_id = 'thumbnails');

create policy "Authenticated users can upload thumbnails"
  on storage.objects for insert
  with check (bucket_id = 'thumbnails' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "Public avatar access"
  on storage.objects for select
  using (bucket_id = 'avatars');

create policy "Users can upload their avatar"
  on storage.objects for insert
  with check (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "Users can update their avatar"
  on storage.objects for update
  using (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);


-- ─────────────────────────────────────────────────────────────
-- 7. HELPER FUNCTIONS
-- ─────────────────────────────────────────────────────────────

-- Automatically create a profile row when a new user signs up
create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

-- Trigger the function on every new auth user
create or replace trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

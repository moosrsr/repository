# Short-Form Video Platform — Setup Guide

A production-ready TikTok-style app built with **React + Vite + TypeScript + Supabase**.

## Features
- 🔐 **Auth** — Supabase Auth (email/password) with protected routes
- 🎬 **Video Feed** — Vertical snap-scroll, auto-play, lazy pagination
- 💬 **Real-time Chat** — Supabase Realtime (Postgres CDC), zero polling
- 📦 **Storage** — Videos & thumbnails served from Supabase Storage
- 👤 **Profiles** — Video grid, follow counts
- 🔍 **Search** — Full-text video search
- ⬆️ **Upload** — Upload to Supabase Storage with progress bar

---

## Step 1 — Create your Supabase project

1. Go to [supabase.com](https://supabase.com) → **New project** → fill in details → **Create**.
2. Wait ~2 minutes for provisioning.

---

## Step 2 — Run the database schema

1. In Supabase Dashboard → **SQL Editor** → **New query**.
2. Open `schema.sql`, paste the entire contents, click **Run**.

This creates all tables, RLS policies, storage buckets, and Realtime in one shot.

---

## Step 3 — Get your API credentials

Dashboard → **Project Settings** → **API** → copy:
- **Project URL** — `https://xxxx.supabase.co`
- **anon / public key** — long JWT string

---

## Step 4 — Configure the app

```bash
cp .env.example .env
```

Edit `.env`:
```
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

---

## Step 5 — Install and run (requires Node.js 18+)

```bash
npm install
npm run dev
```

Open http://localhost:5173

---

## Project structure

```
src/
├── lib/
│   ├── supabase.ts          ← Supabase client + storage helper
│   └── types.ts             ← TypeScript types matching DB schema
├── styles/index.css         ← Global CSS + Tailwind dark theme
└── app/
    ├── App.tsx              ← Root with AuthProvider
    ├── routes.tsx           ← All routes + AppShell layout
    ├── contexts/AuthContext.tsx
    ├── pages/
    │   ├── LoginPage.tsx
    │   ├── SignupPage.tsx
    │   ├── FeedPage.tsx     ← Vertical scroll feed from Supabase Storage
    │   ├── ChatPage.tsx     ← Real-time DMs via Supabase Realtime
    │   ├── SearchPage.tsx
    │   ├── UploadPage.tsx
    │   └── ProfilePage.tsx
    └── components/
        ├── layout/BottomNav.tsx
        ├── layout/ProtectedRoute.tsx
        └── ui/              ← shadcn/ui components
```

---

## How real-time chat works

User sends message → INSERT into DB → Supabase broadcasts CDC event on
channel `conversation:{id}` → receiver's `.on("postgres_changes")` fires →
message appended to React state → UI updates instantly. No manual polling.

---

## Build for production

```bash
npm run build   # outputs to /dist
```

Deploy `/dist` to Vercel, Netlify, or any static host.
